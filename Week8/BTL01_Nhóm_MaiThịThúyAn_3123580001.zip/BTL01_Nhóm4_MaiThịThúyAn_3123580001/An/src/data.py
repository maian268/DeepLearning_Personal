"""Sinh, chia, lưu và khảo sát dữ liệu Gaussian 2D."""
import numpy as np
import pandas as pd
from . import config as cfg


def gaussian_2d(X, mu=cfg.MU, C=cfg.COV):
    """Mật độ Gaussian 2 chiều f(x) = exp(-0.5 (x-mu)^T C^-1 (x-mu)) / (2*pi*sqrt(det C)).
    X: (N, 2) hoặc (2,). Trả về (N,)."""
    X = np.atleast_2d(np.asarray(X, dtype=float))
    C_inv = np.linalg.inv(C)
    det_C = np.linalg.det(C)
    diff = X - mu
    maha = np.einsum("ni,ij,nj->n", diff, C_inv, diff)
    return np.exp(-0.5 * maha) / (2.0 * np.pi * np.sqrt(det_C))


Y_PEAK = float(gaussian_2d(cfg.MU)[0])                    # f(mu), giá trị lớn nhất của hàm
X_SCALE = np.array([abs(cfg.X1_RANGE[1]), abs(cfg.X2_RANGE[1])])   # [2, 4]: nửa biên miền
Y_SCALE = Y_PEAK


def verify_gaussian(n=1000):
    """Đối chiếu hàm tự viết với SciPy (chỉ để kiểm tra)."""
    from scipy.stats import multivariate_normal
    rng = np.random.default_rng(0)
    X = np.column_stack([rng.uniform(*cfg.X1_RANGE, n), rng.uniform(*cfg.X2_RANGE, n)])
    return bool(np.allclose(gaussian_2d(X), multivariate_normal(cfg.MU, cfg.COV).pdf(X)))


def _sample(n, rng):
    X = np.column_stack([rng.uniform(*cfg.X1_RANGE, n), rng.uniform(*cfg.X2_RANGE, n)])
    return X, gaussian_2d(X)


def build_datasets(save=True):
    """Sinh train gốc / validation / test từ 3 dòng ngẫu nhiên ĐỘC LẬP (SeedSequence.spawn)."""
    assert np.all(np.linalg.eigvalsh(cfg.COV) > 0), "C phải xác định dương"
    s_tr, s_va, s_te = np.random.SeedSequence(cfg.DATA_SEED).spawn(3)
    X_pool, y_pool = _sample(cfg.N_POOL, np.random.default_rng(s_tr))
    X_val, y_val = _sample(cfg.N_VAL, np.random.default_rng(s_va))
    X_test, y_test = _sample(cfg.N_TEST, np.random.default_rng(s_te))
    ds = dict(X_pool=X_pool, y_pool=y_pool, X_val=X_val, y_val=y_val, X_test=X_test, y_test=y_test)

    as_set = lambda X: set(map(tuple, X))
    assert not (as_set(X_pool) & as_set(X_val)) and not (as_set(X_pool) & as_set(X_test)) \
        and not (as_set(X_val) & as_set(X_test)), "Các tập bị trùng mẫu"
    if save:
        cfg.ensure_dirs()
        for name, X, y in [("train_pool", X_pool, y_pool), ("val", X_val, y_val), ("test", X_test, y_test)]:
            pd.DataFrame({"x1": X[:, 0], "x2": X[:, 1], "y": y}).to_csv(cfg.DATA_DIR / f"{name}.csv", index=False)
    return ds


def data_statistics(ds, save=True):
    rows = []
    for name, X, y in [("train_pool", ds["X_pool"], ds["y_pool"]), ("val", ds["X_val"], ds["y_val"]),
                       ("test", ds["X_test"], ds["y_test"])]:
        for var, v in [("x1", X[:, 0]), ("x2", X[:, 1]), ("y", y)]:
            rows.append(dict(tap=name, bien=var, n=len(v), mean=v.mean(), std=v.std(ddof=1), min=v.min(), max=v.max()))
    df = pd.DataFrame(rows)
    if save:
        cfg.ensure_dirs()
        df.to_csv(cfg.LOG_DIR / "data_statistics.csv", index=False)
    return df
