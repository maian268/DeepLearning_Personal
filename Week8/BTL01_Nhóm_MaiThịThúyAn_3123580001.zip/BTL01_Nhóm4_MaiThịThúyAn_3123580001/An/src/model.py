"""MLP tùy biến số tầng ẩn / số nơ-ron bằng torch.nn.Module."""
import torch.nn as nn


class MLP(nn.Module):
    """2 -> [Linear(h1)+act] -> ... -> [Linear(hC)+act] -> Linear(1) (tầng ra tuyến tính cho hồi quy)."""
    ACTS = {"tanh": nn.Tanh, "relu": nn.ReLU, "sigmoid": nn.Sigmoid}

    def __init__(self, in_dim=2, hidden_sizes=(32, 32), out_dim=1, activation="tanh"):
        super().__init__()
        layers, prev = [], in_dim
        for h in hidden_sizes:
            layers += [nn.Linear(prev, h), self.ACTS[activation]()]
            prev = h
        layers.append(nn.Linear(prev, out_dim))
        self.net = nn.Sequential(*layers)

    def forward(self, x):
        return self.net(x)


def count_params(model):
    return sum(p.numel() for p in model.parameters() if p.requires_grad)
