"""Chạy nhóm thực nghiệm A/B/C, ghi log CSV, bảng tổng hợp, biểu đồ và checkpoint tốt nhất."""
import json
import platform
import time
import numpy as np
import pandas as pd
import torch
from . import config as cfg
from . import plots
from .data import X_SCALE, Y_SCALE, Y_PEAK
from .model import MLP
from .train import run_single, get_device, predict, regression_metrics

METRICS = ["train_mse", "val_mse", "test_mse", "test_rmse", "test_mae", "test_r2", "train_time_s", "best_epoch", "epochs_run", "n_params"]


def _cfg_json(d):
    return {k: (list(v) if isinstance(v, tuple) else v) for k, v in d.items()}


def summarize(runs):
    s = runs.groupby("factor_value")[METRICS].agg(["mean", "std"])
    s.columns = [f"{m}_{a}" for m, a in s.columns]
    return s.reset_index().fillna(0.0)


def pretty_table(summary, spec):
    f = lambda c: summary[f"{c}_mean"].map(lambda v: f"{v:.3e}") + " ± " + summary[f"{c}_std"].map(lambda v: f"{v:.1e}")
    return pd.DataFrame({
        spec["short"]: summary["factor_value"].astype(int),
        "Số tham số": summary["n_params_mean"].round(0).astype(int),
        "Train MSE": f("train_mse"), "Val MSE": f("val_mse"), "Test MSE": f("test_mse"),
        "Test RMSE": f("test_rmse"), "Test MAE": f("test_mae"),
        "Test R²": summary["test_r2_mean"].map(lambda v: f"{v:.4f}"),
        "Thời gian (s)": summary["train_time_s_mean"].round(1),
        "Epoch tốt nhất": summary["best_epoch_mean"].round(0).astype(int),
    })


def run_group(group, ds, quick=False, seeds=None, device=None, verbose=True):
    spec = cfg.group_spec(group, quick)
    train_cfg = dict(cfg.TRAIN)
    if quick:
        train_cfg.update(max_epochs=cfg.QUICK["max_epochs"], patience=cfg.QUICK["patience"])
    seeds = seeds if seeds is not None else (cfg.QUICK["seeds"] if quick else cfg.SEEDS)
    device = device or get_device(False)
    cfg.ensure_dirs()
    g = spec["group"]
    ckpt_path = cfg.MODEL_DIR / f"best_{g}.pt"

    rows, hist, best_val = [], [], float("inf")
    t_all = time.perf_counter()
    for v in spec["values"]:
        n_train, hidden = spec["build"](v)
        for seed in seeds:
            model, row, h = run_single(ds, n_train, hidden, seed, train_cfg, device)
            row.update(group=g, factor_value=v)
            rows.append(row)
            hist += [dict(group=g, factor_value=v, seed=seed, **x) for x in h]
            if verbose:
                print(f"[{g}] {spec['short']}={v:<4} seed={seed} | n_train={n_train} hidden={row['hidden']:<12} "
                      f"| epoch={row['epochs_run']:3d} (best {row['best_epoch']:3d}) | val={row['val_mse']:.3e} "
                      f"test={row['test_mse']:.3e} | {row['train_time_s']:.1f}s", flush=True)
            if row["val_mse"] < best_val:     # chọn theo VALIDATION, không theo test
                best_val = row["val_mse"]
                torch.save(dict(state_dict=model.state_dict(), group=g, factor_value=float(v), seed=int(seed),
                                n_train=int(n_train), hidden_sizes=list(hidden), activation=train_cfg["activation"],
                                val_mse=float(row["val_mse"]), x_scale=X_SCALE.tolist(), y_scale=float(Y_SCALE),
                                config=_cfg_json(train_cfg)), ckpt_path)
    if verbose:
        print(f"[{g}] xong {len(rows)} lần chạy trong {(time.perf_counter() - t_all) / 60:.1f} phút")

    runs, hist_df = pd.DataFrame(rows), pd.DataFrame(hist)
    summary = summarize(runs)
    runs.to_csv(cfg.LOG_DIR / f"results_{g}_runs.csv", index=False)
    hist_df.to_csv(cfg.LOG_DIR / f"history_{g}.csv", index=False)
    summary.to_csv(cfg.LOG_DIR / f"results_{g}_summary.csv", index=False)
    pretty_table(summary, spec).to_csv(cfg.LOG_DIR / f"results_{g}_table.csv", index=False)
    plots.plot_group(spec, runs, hist_df, summary)
    return runs, hist_df, summary


def dump_config(quick=False):
    seeds = cfg.QUICK["seeds"] if quick else cfg.SEEDS
    out = dict(mu=cfg.MU.tolist(), C=cfg.COV.tolist(), x1_range=cfg.X1_RANGE, x2_range=cfg.X2_RANGE,
               data_seed=cfg.DATA_SEED, n_pool=cfg.N_POOL, n_val=cfg.N_VAL, n_test=cfg.N_TEST,
               seeds=seeds, train=_cfg_json(cfg.TRAIN), A_list=cfg.A_LIST, A_hidden=list(cfg.A_HIDDEN),
               B_list=cfg.B_LIST, C_list=cfg.C_LIST, C_width=cfg.C_WIDTH, n_fixed_BC=cfg.N_FIXED,
               quick_mode=bool(quick), x_scale=X_SCALE.tolist(), y_scale=float(Y_SCALE),
               torch=torch.__version__, numpy=np.__version__, pandas=pd.__version__, python=platform.python_version())
    cfg.ensure_dirs()
    with open(cfg.LOG_DIR / "config.json", "w", encoding="utf-8") as f:
        json.dump(out, f, indent=2, ensure_ascii=False)


def final_evaluation(ds, device=None):
    """Chọn mô hình có validation MSE nhỏ nhất trong các checkpoint A/B/C, rồi ĐÁNH GIÁ CUỐI trên test."""
    device = device or get_device(False)
    cands = [(torch.load(p, map_location=device), p) for p in sorted(cfg.MODEL_DIR.glob("best_[ABC].pt"))]
    if not cands:
        raise FileNotFoundError("Chưa có checkpoint: hãy chạy thực nghiệm A/B/C trước.")
    ckpt, path = min(cands, key=lambda t: t[0]["val_mse"])
    model = MLP(2, ckpt["hidden_sizes"], 1, ckpt["activation"]).to(device)
    model.load_state_dict(ckpt["state_dict"]); model.eval()
    torch.save(ckpt, cfg.MODEL_DIR / "best_model.pt")

    yhat = predict(model, ds["X_test"], device)
    m = regression_metrics(ds["y_test"], yhat)
    emax, emean = plots.plot_final(ds["y_test"], yhat, lambda X: predict(model, X, device), ds["X_test"], ds["X_pool"][:ckpt["n_train"]])
    plots.plot_architecture(tuple(ckpt["hidden_sizes"]), "fig_best_architecture.png")
    info = dict(selected_from=path.name, group=ckpt["group"], factor_value=ckpt["factor_value"], seed=ckpt["seed"],
                n_train=ckpt["n_train"], hidden_sizes=ckpt["hidden_sizes"], val_mse=ckpt["val_mse"],
                test_mse=m["mse"], test_rmse=m["rmse"], test_mae=m["mae"], test_r2=m["r2"],
                grid_abs_err_max=emax, grid_abs_err_mean=emean, y_peak=Y_PEAK)
    with open(cfg.LOG_DIR / "final_test_metrics.json", "w", encoding="utf-8") as f:
        json.dump(info, f, indent=2, ensure_ascii=False)
    print("Mô hình cuối:", {k: info[k] for k in ("group", "factor_value", "seed", "hidden_sizes", "val_mse", "test_mse", "test_rmse", "test_mae")})
    return info
