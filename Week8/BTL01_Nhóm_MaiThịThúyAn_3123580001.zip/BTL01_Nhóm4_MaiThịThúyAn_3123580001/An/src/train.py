"""Vòng lặp train/validation, checkpoint, dự đoán và chỉ số đánh giá."""
import copy
import random
import time
import numpy as np
import torch
import torch.nn as nn
from torch.utils.data import TensorDataset, DataLoader
from .data import X_SCALE, Y_SCALE
from .model import MLP, count_params


def get_device(use_gpu=False):
    return torch.device("cuda" if (use_gpu and torch.cuda.is_available()) else "cpu")


def set_seed(seed):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


# ---- Chuẩn hóa: hằng số theo miền/hàm, KHÔNG phụ thuộc dữ liệu -> không rò rỉ ----
def prep_x(X):
    return torch.tensor(np.asarray(X) / X_SCALE, dtype=torch.float32)


def prep_y(y):
    return torch.tensor((np.asarray(y) / Y_SCALE).reshape(-1, 1), dtype=torch.float32)


def make_loader(X, y, batch_size, shuffle, seed=None):
    ds = TensorDataset(prep_x(X), prep_y(y))
    gen = None
    if shuffle:
        gen = torch.Generator()
        gen.manual_seed(0 if seed is None else int(seed))
    return DataLoader(ds, batch_size=batch_size, shuffle=shuffle, generator=gen)


def regression_metrics(y_true, y_pred):
    err = np.asarray(y_pred) - np.asarray(y_true)
    mse = float(np.mean(err ** 2))
    ss_tot = float(np.sum((y_true - np.mean(y_true)) ** 2))
    return dict(mse=mse, rmse=mse ** 0.5, mae=float(np.mean(np.abs(err))),
                r2=float(1.0 - np.sum(err ** 2) / ss_tot))


def evaluate_loss(model, loader, criterion, device):
    model.eval()
    total, n = 0.0, 0
    with torch.no_grad():
        for xb, yb in loader:
            xb, yb = xb.to(device), yb.to(device)
            total += criterion(model(xb), yb).item() * xb.size(0)
            n += xb.size(0)
    return total / n


def train_model(model, train_loader, val_loader, cfg, device):
    """forward -> loss -> zero_grad -> backward -> step; early stopping + checkpoint theo validation."""
    criterion = nn.MSELoss()
    if cfg["optimizer"].lower() == "adam":
        optimizer = torch.optim.Adam(model.parameters(), lr=cfg["lr"])
    else:
        optimizer = torch.optim.SGD(model.parameters(), lr=cfg["lr"], momentum=0.9)

    best_val, best_state, best_epoch, wait = float("inf"), None, 0, 0
    history = []
    for epoch in range(1, cfg["max_epochs"] + 1):
        model.train()
        run_loss, n_seen = 0.0, 0
        for xb, yb in train_loader:
            xb, yb = xb.to(device), yb.to(device)
            y_hat = model(xb)                      # forward
            loss = criterion(y_hat, yb)            # loss
            optimizer.zero_grad()                  # xóa gradient cũ
            loss.backward()                        # backpropagation
            optimizer.step()                       # cập nhật trọng số
            run_loss += loss.item() * xb.size(0)
            n_seen += xb.size(0)
        train_loss = run_loss / n_seen
        val_loss = evaluate_loss(model, val_loader, criterion, device)
        history.append(dict(epoch=epoch, train_mse=train_loss * Y_SCALE ** 2, val_mse=val_loss * Y_SCALE ** 2))

        if val_loss < best_val * (1.0 - cfg["rel_tol"]):
            best_val, best_epoch, wait = val_loss, epoch, 0
            best_state = copy.deepcopy(model.state_dict())
        else:
            wait += 1
            if wait >= cfg["patience"]:
                break

    model.load_state_dict(best_state)
    return model, history, dict(best_epoch=best_epoch, epochs_run=len(history))


def predict(model, X, device):
    """Dự đoán trên thang đo gốc của y."""
    model.eval()
    with torch.no_grad():
        out = model(prep_x(X).to(device)).cpu().numpy().ravel()
    return out * Y_SCALE


def run_single(ds, n_train, hidden_sizes, seed, cfg, device):
    """Một lần chạy: train trên n_train mẫu đầu của tập gốc; trả về (model, hàng kết quả, lịch sử loss)."""
    set_seed(seed)
    X_tr, y_tr = ds["X_pool"][:n_train], ds["y_pool"][:n_train]
    train_loader = make_loader(X_tr, y_tr, cfg["batch_size"], True, seed)
    val_loader = make_loader(ds["X_val"], ds["y_val"], 512, False)
    model = MLP(2, hidden_sizes, 1, cfg["activation"]).to(device)

    t0 = time.perf_counter()
    model, history, info = train_model(model, train_loader, val_loader, cfg, device)
    elapsed = time.perf_counter() - t0

    m_tr = regression_metrics(y_tr, predict(model, X_tr, device))
    m_va = regression_metrics(ds["y_val"], predict(model, ds["X_val"], device))
    m_te = regression_metrics(ds["y_test"], predict(model, ds["X_test"], device))
    row = dict(n_train=n_train, hidden="-".join(map(str, hidden_sizes)), n_layers=len(hidden_sizes),
               seed=seed, n_params=count_params(model), best_epoch=info["best_epoch"],
               epochs_run=info["epochs_run"], train_time_s=elapsed,
               train_mse=m_tr["mse"], val_mse=m_va["mse"], test_mse=m_te["mse"],
               test_rmse=m_te["rmse"], test_mae=m_te["mae"], test_r2=m_te["r2"])
    return model, row, history
