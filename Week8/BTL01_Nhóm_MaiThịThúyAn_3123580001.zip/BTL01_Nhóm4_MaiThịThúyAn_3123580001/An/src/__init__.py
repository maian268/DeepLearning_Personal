"""BTL01 - Xấp xỉ hàm Gaussian 2D bằng MLP (PyTorch)."""
