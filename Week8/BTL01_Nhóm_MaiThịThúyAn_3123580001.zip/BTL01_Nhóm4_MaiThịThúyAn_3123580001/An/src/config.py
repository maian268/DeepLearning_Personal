"""Toàn bộ cấu hình thực nghiệm (một nơi duy nhất để chỉnh siêu tham số)."""
import os
from pathlib import Path
import numpy as np

ROOT = Path(__file__).resolve().parent.parent
# Có thể đổi thư mục xuất kết quả bằng biến môi trường BTL01_OUT (mặc định: thư mục dự án)
OUT = Path(os.environ.get("BTL01_OUT", ROOT))
DATA_DIR, LOG_DIR, FIG_DIR = OUT / "data", OUT / "logs", OUT / "figures"
MODEL_DIR, REPORT_DIR, SLIDE_DIR = OUT / "models", OUT / "report", OUT / "slides"


def ensure_dirs():
    for d in (DATA_DIR, LOG_DIR, FIG_DIR, MODEL_DIR, REPORT_DIR, SLIDE_DIR):
        d.mkdir(parents=True, exist_ok=True)


# ---------------- Bài toán ----------------
MU = np.array([0.0, 0.0])
COV = np.array([[0.3, -0.5], [-0.5, 2.0]])
X1_RANGE = (-2.0, 2.0)
X2_RANGE = (-4.0, 4.0)

# ---------------- Dữ liệu ----------------
DATA_SEED = 2024                 # seed sinh dữ liệu: cố định cho MỌI thí nghiệm
N_POOL, N_VAL, N_TEST = 2000, 400, 100   # train gốc (đủ cho A lớn nhất) / validation / test

# ---------------- Huấn luyện (giống nhau cho mọi nhóm A, B, C) ----------------
SEEDS = [0, 1, 2]                # seed khởi tạo trọng số + xáo trộn batch (báo cáo mean ± std)
TRAIN = dict(
    optimizer="adam", lr=3e-3, batch_size=32,
    max_epochs=500, patience=50, rel_tol=1e-3,   # dừng sớm theo validation
    activation="tanh", loss="MSELoss",
)

# ---------------- Ba nhóm thực nghiệm ----------------
A_LIST = list(range(200, 2001, 200))         # A: số mẫu train (200..2000)
A_HIDDEN = (32, 32)                          # kiến trúc chuẩn (baseline) của nhóm A
B_LIST = list(range(1, 11)) + [15, 20, 30, 50]   # B: số nơ-ron, MLP 1 tầng ẩn (1..10 + mở rộng)
C_LIST = [1, 2, 3, 4, 5]                     # C: số tầng ẩn
C_WIDTH = 16                                 # số nơ-ron mỗi tầng ẩn trong nhóm C
N_FIXED = 1000                               # số mẫu train cố định cho nhóm B và C

QUICK = dict(seeds=[0], max_epochs=30, patience=10,
             A=[200, 1000, 2000], B=[1, 2, 4, 10], C=[1, 2, 3])


def group_spec(group, quick=False):
    """Mô tả từng nhóm: giá trị khảo sát và cách dựng (n_train, hidden_sizes)."""
    group = group.upper()
    if group == "A":
        vals = QUICK["A"] if quick else A_LIST
        return dict(group="A", name="Số mẫu huấn luyện A", short="A", values=vals, log_x=False,
                    build=lambda v: (int(v), tuple(A_HIDDEN)))
    if group == "B":
        vals = QUICK["B"] if quick else B_LIST
        return dict(group="B", name="Số nơ-ron tầng ẩn B (1 tầng ẩn)", short="B", values=vals, log_x=True,
                    build=lambda v: (N_FIXED, (int(v),)))
    if group == "C":
        vals = QUICK["C"] if quick else C_LIST
        return dict(group="C", name="Số tầng ẩn C", short="C", values=vals, log_x=False,
                    build=lambda v: (N_FIXED, (C_WIDTH,) * int(v)))
    raise ValueError(f"Nhóm không hợp lệ: {group}")
