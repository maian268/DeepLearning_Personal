"""Đọc log và sinh nhận xét MÔ TẢ SỐ LIỆU (dùng chung cho báo cáo và slide).
Các câu nhận xét được tạo từ số liệu thực trong logs/, không chứa số liệu cố định."""
import json
import numpy as np
import pandas as pd
from . import config as cfg
from .data import Y_PEAK


def _csv(name):
    p = cfg.LOG_DIR / name
    return pd.read_csv(p) if p.exists() else None


def load_all():
    out = dict(stats=_csv("data_statistics.csv"), config=None, final=None)
    for g in "ABC":
        out[g] = _csv(f"results_{g}_summary.csv")
        out[f"{g}_runs"] = _csv(f"results_{g}_runs.csv")
    for key, name in [("config", "config.json"), ("final", "final_test_metrics.json")]:
        p = cfg.LOG_DIR / name
        if p.exists():
            out[key] = json.load(open(p, encoding="utf-8"))
    return out


def fmt(v):
    return f"{v:.2e}"


def near_zero_pct():
    p = cfg.DATA_DIR / "train_pool.csv"
    if not p.exists():
        return None
    y = pd.read_csv(p)["y"].values
    return float(np.mean(y < 0.01 * Y_PEAK) * 100)


def _ratio(a, b):
    return a / max(b, 1e-30)


def _nonmono(series):
    """Các giá trị khảo sát mà sai số KHÔNG giảm so với mức liền trước."""
    idx = list(series.index)
    return [idx[i + 1] for i, d in enumerate(np.diff(series.values)) if d > 0]


def analyze_A(s):
    g = s.set_index("factor_value")
    a0, a1 = int(g.index[0]), int(g.index[-1])
    t0, t1 = g["test_mse_mean"].iloc[0], g["test_mse_mean"].iloc[-1]
    v0, v1 = g["val_mse_mean"].iloc[0], g["val_mse_mean"].iloc[-1]
    best = int(g["val_mse_mean"].idxmin())
    sat = int(g.index[g["val_mse_mean"] <= 1.25 * g["val_mse_mean"].min()][0])
    r0 = _ratio(g["val_mse_mean"].iloc[0], g["train_mse_mean"].iloc[0])
    r1 = _ratio(g["val_mse_mean"].iloc[-1], g["train_mse_mean"].iloc[-1])
    nm = [int(x) for x in _nonmono(g["val_mse_mean"])]
    nz = near_zero_pct()

    short = [f"Test MSE thay đổi {t0 / t1:.1f} lần khi A tăng từ {a0} lên {a1} ({fmt(t0)} → {fmt(t1)}).",
             f"Validation MSE nhỏ nhất tại A={best}; từ A={sat} sai số đã nằm trong 25% so với mức tốt nhất.",
             f"Tỉ lệ Val/Train MSE: {r0:.1f} (A={a0}) → {r1:.1f} (A={a1})."]
    paras = [f"Khi tăng số mẫu huấn luyện từ {a0} lên {a1}, validation MSE trung bình đi từ {fmt(v0)} xuống {fmt(v1)} "
             f"và test MSE trung bình từ {fmt(t0)} xuống {fmt(t1)} (tỉ lệ {t0 / t1:.1f} lần). "
             f"Validation MSE nhỏ nhất đạt ở A = {best}; từ A = {sat} sai số đã nằm trong khoảng 25% so với mức tốt nhất."]
    if t0 / t1 > 1.5:
        paras.append("Xu hướng giảm sai số khi tăng A phù hợp với kỳ vọng: nhiều mẫu hơn giúp mạng ước lượng tốt hơn các tham số "
                     "và phủ dày hơn vùng quanh đỉnh của hàm Gaussian"
                     + (f" (chỉ khoảng {100 - nz:.0f}% mẫu train có y lớn hơn 1% giá trị đỉnh, nên số mẫu rơi vào vùng đỉnh rất hạn chế khi A nhỏ)." if nz is not None else "."))
    else:
        paras.append("Sai số thay đổi không đáng kể khi tăng A, cho thấy với cấu hình chuẩn mô hình bị giới hạn bởi dung lượng hoặc quá trình tối ưu hơn là bởi số mẫu.")
    paras.append(f"Tỉ lệ Val/Train MSE đổi từ {r0:.1f} (A = {a0}) sang {r1:.1f} (A = {a1}); "
                 + ("khoảng cách tổng quát hóa thu hẹp khi có nhiều dữ liệu hơn." if r1 < r0 else "khoảng cách này không thu hẹp khi tăng A."))
    notable = [f"A = {x}: validation MSE trung bình không giảm so với mức A liền trước (nằm trong độ lệch giữa các seed hoặc do early stopping)." for x in nm]
    return dict(short=short, paras=paras, notable=notable, best=best)


def analyze_B(s):
    g = s.set_index("factor_value")
    best = int(g["val_mse_mean"].idxmin()); vmin = g["val_mse_mean"].min()
    under = [int(b) for b in g.index if g.loc[b, "val_mse_mean"] > 2 * vmin and b < best]
    over = [int(b) for b in g.index if b > best and g.loc[b, "val_mse_mean"] > 1.1 * vmin]
    b0 = int(g.index[0]); bl = int(g.index[-1])
    gap_best = _ratio(g.loc[best, "val_mse_mean"], g.loc[best, "train_mse_mean"])
    gap_last = _ratio(g.loc[bl, "val_mse_mean"], g.loc[bl, "train_mse_mean"])
    sat = int(g.index[g["val_mse_mean"] <= 1.25 * vmin][0])
    short = [f"Validation MSE nhỏ nhất tại B={best} ({fmt(vmin)}); B={b0} cho {fmt(g.loc[b0, 'val_mse_mean'])}.",
             (f"Thiếu khớp (val MSE > 2× mức tốt nhất) ở B ∈ {under}." if under else "Không có B nào thuộc vùng thiếu khớp rõ rệt trong phạm vi khảo sát."),
             (f"Dấu hiệu quá khớp: val MSE tăng >10% so với tốt nhất ở B ∈ {over}." if over else f"Chưa thấy quá khớp: val MSE không tăng khi B lên tới {bl}.")]
    paras = [f"Với MLP một tầng ẩn, validation MSE trung bình nhỏ nhất ở B = {best} ({fmt(vmin)}); từ B = {sat} sai số đã nằm trong 25% mức tốt nhất. "
             f"Với B = {b0}, val MSE là {fmt(g.loc[b0, 'val_mse_mean'])}, gấp {g.loc[b0, 'val_mse_mean'] / vmin:.1f} lần mức tốt nhất."]
    if under:
        paras.append(f"Vùng thiếu khớp (underfitting) gồm B ∈ {under}: cả train MSE và validation MSE cùng cao. "
                     "Một nơ-ron tanh chỉ tạo hàm không đổi theo phương vuông góc với vectơ trọng số, nên không thể biểu diễn đỉnh Gaussian cục bộ; "
                     "cần đủ nơ-ron để tổ hợp nhiều hàm kiểu 'bậc thang' thành một đỉnh.")
    if over:
        paras.append(f"Khi B ≥ {over[0]}, val MSE tăng trở lại so với mức tốt nhất trong khi train MSE vẫn thấp, tỉ lệ Val/Train đạt {gap_last:.1f} ở B = {bl}: dấu hiệu quá khớp (overfitting).")
    else:
        paras.append(f"Trong phạm vi B ≤ {bl}, validation MSE không tăng trở lại đáng kể; tỉ lệ Val/Train là {gap_best:.1f} tại B = {best} và {gap_last:.1f} tại B = {bl}. "
                     "Với 1000 mẫu không nhiễu và early stopping theo validation, mô hình lớn hơn chưa gây quá khớp rõ rệt.")
    notable = [f"B = {int(x)}: validation MSE trung bình không giảm so với mức B liền trước." for x in _nonmono(g["val_mse_mean"])]
    return dict(short=short, paras=paras, notable=notable, best=best)


def analyze_C(s):
    g = s.set_index("factor_value")
    best = int(g["val_mse_mean"].idxmin())
    c0, cl = int(g.index[0]), int(g.index[-1])
    tt0, tt1 = g["train_time_s_mean"].iloc[0], g["train_time_s_mean"].iloc[-1]
    e0, e1 = g["best_epoch_mean"].iloc[0], g["best_epoch_mean"].iloc[-1]
    te0, te_best = g["test_mse_mean"].iloc[0], g.loc[best, "test_mse_mean"]
    short = [f"Test MSE: {fmt(te0)} (C={c0}) → {fmt(te_best)} (C={best}, val tốt nhất).",
             f"Thời gian huấn luyện: {tt0:.1f}s (C={c0}) → {tt1:.1f}s (C={cl}), gấp {tt1 / max(tt0, 1e-9):.1f} lần.",
             f"Epoch đạt validation tốt nhất trung bình: {e0:.0f} (C={c0}) → {e1:.0f} (C={cl})."]
    paras = [f"Validation MSE trung bình nhỏ nhất ở C = {best}; test MSE tại đó là {fmt(te_best)} so với {fmt(te0)} ở C = {c0}. "
             f"Thời gian huấn luyện tăng từ {tt0:.1f}s lên {tt1:.1f}s (gấp {tt1 / max(tt0, 1e-9):.1f} lần) khi C tăng từ {c0} lên {cl}, "
             "do mỗi bước lan truyền xuôi/ngược phải đi qua nhiều tầng hơn và số tham số tăng."]
    if best < cl:
        paras.append(f"Tăng độ sâu vượt quá C = {best} không còn cải thiện validation MSE; mạng sâu hơn khó tối ưu hơn với cùng learning rate và điều kiện dừng, "
                     "trong khi hàm cần xấp xỉ khá đơn giản (một đỉnh trơn).")
    else:
        paras.append(f"Validation MSE tiếp tục cải thiện tới C = {cl} (giá trị lớn nhất khảo sát), nên có thể thử thêm tầng ẩn.")
    paras.append(f"Số epoch tới checkpoint tốt nhất thay đổi từ {e0:.0f} (C = {c0}) đến {e1:.0f} (C = {cl}); xem đường cong hội tụ trong biểu đồ loss theo epoch.")
    notable = [f"C = {int(x)}: validation MSE trung bình không giảm so với mức C liền trước." for x in _nonmono(g["val_mse_mean"])]
    return dict(short=short, paras=paras, notable=notable, best=best)


def best_rows(all_):
    """Dòng tốt nhất (theo validation) của mỗi nhóm, để làm bảng tổng hợp."""
    rows = []
    for g, lab in [("A", "A (số mẫu train)"), ("B", "B (nơ-ron, 1 tầng ẩn)"), ("C", "C (số tầng ẩn)")]:
        s = all_.get(g)
        if s is None:
            continue
        r = s.loc[s["val_mse_mean"].idxmin()]
        rows.append(dict(group=g, label=lab, value=int(r["factor_value"]), val=r["val_mse_mean"], test=r["test_mse_mean"],
                         rmse=r["test_rmse_mean"], mae=r["test_mae_mean"], time=r["train_time_s_mean"], params=int(round(r["n_params_mean"]))))
    return rows
