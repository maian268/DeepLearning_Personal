"""Biểu đồ: dữ liệu, kiến trúc MLP, kết quả từng nhóm A/B/C và mô hình cuối."""
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from . import config as cfg
from .data import gaussian_2d, Y_PEAK


def _save(name):
    cfg.ensure_dirs()
    plt.savefig(cfg.FIG_DIR / name, dpi=200, bbox_inches="tight")
    plt.close()


def make_grid(n=120):
    g1, g2 = np.linspace(*cfg.X1_RANGE, n), np.linspace(*cfg.X2_RANGE, n)
    G1, G2 = np.meshgrid(g1, g2)
    grid = np.column_stack([G1.ravel(), G2.ravel()])
    return G1, G2, grid, gaussian_2d(grid).reshape(G1.shape)


# ----------------------------------------------------------------- dữ liệu
def plot_data(ds):
    G1, G2, _, Z = make_grid()
    fig = plt.figure(figsize=(8, 6))
    ax = fig.add_subplot(111, projection="3d")
    ax.scatter(ds["X_pool"][:, 0], ds["X_pool"][:, 1], ds["y_pool"], s=5, alpha=0.45, c="tab:blue", label=f"Train gốc (n={len(ds['y_pool'])})")
    ax.scatter(ds["X_val"][:, 0], ds["X_val"][:, 1], ds["y_val"], s=8, alpha=0.7, c="tab:orange", label=f"Validation (n={len(ds['y_val'])})")
    ax.scatter(ds["X_test"][:, 0], ds["X_test"][:, 1], ds["y_test"], s=14, alpha=0.9, c="tab:red", label=f"Test (n={len(ds['y_test'])})")
    ax.set_xlabel("$x_1$"); ax.set_ylabel("$x_2$"); ax.set_zlabel("$y=f(x_1,x_2)$")
    ax.legend(loc="upper left", fontsize=8)
    _save("fig01_data_scatter3d.png")

    fig = plt.figure(figsize=(12, 5))
    ax = fig.add_subplot(121, projection="3d")
    s = ax.plot_surface(G1, G2, Z, cmap="viridis", linewidth=0)
    ax.set_xlabel("$x_1$"); ax.set_ylabel("$x_2$"); ax.set_zlabel("$f$"); ax.set_title("Bề mặt hàm Gaussian thật")
    fig.colorbar(s, ax=ax, shrink=0.6, pad=0.2)
    ax2 = fig.add_subplot(122)
    cs = ax2.contourf(G1, G2, Z, levels=20, cmap="viridis")
    ax2.scatter(ds["X_pool"][:, 0], ds["X_pool"][:, 1], s=3, c="white", alpha=0.5, label="Train gốc")
    ax2.set_xlabel("$x_1$"); ax2.set_ylabel("$x_2$"); ax2.set_title("Đường đồng mức và vị trí mẫu train")
    ax2.legend(loc="upper right", fontsize=8); fig.colorbar(cs, ax=ax2)
    _save("fig02_true_surface.png")

    fig, axes = plt.subplots(1, 3, figsize=(13, 3.6))
    for a, v, lab, col in zip(axes, [ds["X_pool"][:, 0], ds["X_pool"][:, 1], ds["y_pool"]], ["$x_1$", "$x_2$", "$y$"],
                              ["tab:blue", "tab:green", "tab:purple"]):
        a.hist(v, bins=30, color=col, alpha=0.8, edgecolor="white"); a.set_xlabel(lab); a.set_ylabel("Số mẫu")
    axes[0].set_title("Phân bố $x_1$"); axes[1].set_title("Phân bố $x_2$"); axes[2].set_title("Phân bố $y$")
    _save("fig03_distributions.png")


# ----------------------------------------------------------------- kiến trúc
def plot_architecture(hidden_sizes=(32, 32), name="fig_architecture.png"):
    sizes = [2] + list(hidden_sizes) + [1]
    labels = ["Đầu vào\n$(x_1, x_2)$"] + [f"Tầng ẩn {i + 1}\n{h} nơ-ron + tanh" for i, h in enumerate(hidden_sizes)] + ["Đầu ra\n$\\hat y$ (tuyến tính)"]
    fig, ax = plt.subplots(figsize=(2.4 + 2.2 * len(sizes), 4.4))
    xs = np.linspace(0, 1, len(sizes)); shown = []
    for i, n in enumerate(sizes):
        k = min(n, 6); ys = np.linspace(0.15, 0.85, k) if k > 1 else np.array([0.5])
        shown.append((xs[i], ys))
        ax.scatter([xs[i]] * k, ys, s=380, c=["#cfe3ff" if 0 < i < len(sizes) - 1 else "#ffe2b8"] * k, edgecolors="k", zorder=3)
        if n > k:
            ax.text(xs[i], 0.05, f"⋮ ({n})", ha="center", fontsize=10)
        ax.text(xs[i], 1.0, labels[i], ha="center", va="bottom", fontsize=9)
    for (x0, y0s), (x1, y1s) in zip(shown[:-1], shown[1:]):
        for ya in y0s:
            for yb in y1s:
                ax.plot([x0, x1], [ya, yb], color="gray", lw=0.4, zorder=1)
    ax.set_xlim(-0.08, 1.08); ax.set_ylim(0, 1.2); ax.axis("off")
    _save(name)


# ----------------------------------------------------------------- nhóm A/B/C
def _pick(values, k=4):
    if len(values) <= k:
        return list(values)
    idx = np.unique(np.round(np.linspace(0, len(values) - 1, k)).astype(int))
    return [values[i] for i in idx]


def plot_group(spec, runs, hist, summary):
    g, xv, label = spec["group"], summary["factor_value"].values, spec["name"]
    log_x = spec["log_x"]

    def style(ax):
        if log_x:
            ax.set_xscale("log")
        ax.set_xticks(xv); ax.set_xticklabels([str(int(v)) for v in xv], fontsize=8)
        ax.minorticks_off(); ax.grid(alpha=0.3, which="both"); ax.set_xlabel(label)

    # MSE train/val/test
    fig, ax = plt.subplots(figsize=(7.5, 4.8))
    for key, lab, col, mk in [("train_mse", "Train", "tab:blue", "o"), ("val_mse", "Validation", "tab:orange", "s"), ("test_mse", "Test", "tab:red", "^")]:
        ax.errorbar(xv, summary[f"{key}_mean"], yerr=summary[f"{key}_std"], label=lab, color=col, marker=mk, capsize=3, lw=1.6)
    ax.set_yscale("log"); ax.set_ylabel("MSE (thang log)"); ax.legend(fontsize=8); style(ax)
    _save(f"fig_{g}_mse.png")

    # RMSE + MAE test
    fig, ax = plt.subplots(figsize=(7.5, 4.8))
    for key, lab, col, mk in [("test_rmse", "Test RMSE", "tab:purple", "o"), ("test_mae", "Test MAE", "tab:green", "s")]:
        ax.errorbar(xv, summary[f"{key}_mean"], yerr=summary[f"{key}_std"], label=lab, color=col, marker=mk, capsize=3, lw=1.6)
    ax.set_yscale("log"); ax.set_ylabel("Sai số (cùng thang với y, log)"); ax.legend(); style(ax)
    _save(f"fig_{g}_rmse_mae.png")

    # Đường cong học
    sel = _pick(list(xv), 4)
    cols = ["tab:blue", "tab:green", "tab:red", "tab:purple"]
    seed0 = int(runs["seed"].min())
    fig, ax = plt.subplots(figsize=(8, 5))
    for v, c in zip(sel, cols):
        h = hist[(hist.factor_value == v) & (hist.seed == seed0)]
        ax.plot(h.epoch, h.train_mse, color=c, lw=1.3, label=f"{spec['short']}={int(v)} – train")
        ax.plot(h.epoch, h.val_mse, color=c, lw=1.3, ls="--", label=f"{spec['short']}={int(v)} – validation")
    ax.set_yscale("log"); ax.set_xlabel("Epoch"); ax.set_ylabel("MSE (thang log)"); ax.grid(alpha=0.3, which="both"); ax.legend(fontsize=7, ncol=2)
    _save(f"fig_{g}_curves.png")

    # Thời gian + epoch
    fig, axes = plt.subplots(1, 2, figsize=(11, 4.2))
    axes[0].errorbar(xv, summary["train_time_s_mean"], yerr=summary["train_time_s_std"], marker="o", color="tab:cyan", capsize=3)
    axes[0].set_ylabel("Thời gian huấn luyện (s)"); style(axes[0])
    axes[1].errorbar(xv, summary["best_epoch_mean"], yerr=summary["best_epoch_std"], marker="s", color="tab:brown", capsize=3)
    axes[1].set_ylabel("Epoch đạt validation tốt nhất"); style(axes[1])
    _save(f"fig_{g}_time.png")


# ----------------------------------------------------------------- mô hình cuối
def plot_final(y_test, yhat, predict_fn, X_test, X_train_used, title_suffix=""):
    G1, G2, grid, Z = make_grid()
    Zp = predict_fn(grid).reshape(G1.shape)
    err = np.abs(Zp - Z)

    fig, ax = plt.subplots(figsize=(5.5, 5.2))
    ax.scatter(y_test, yhat, s=18, alpha=0.8, color="tab:red", label="Mẫu test")
    lim = [0, max(y_test.max(), yhat.max()) * 1.05]
    ax.plot(lim, lim, "k--", lw=1, label="Dự đoán hoàn hảo ($\\hat y=y$)")
    ax.set_xlim(lim); ax.set_ylim(lim); ax.set_aspect("equal"); ax.grid(alpha=0.3); ax.legend(fontsize=8)
    ax.set_xlabel("$y$ thật"); ax.set_ylabel("$\\hat y$ dự đoán")
    _save("fig_final_y_vs_yhat.png")

    zmax = max(Z.max(), Zp.max())
    fig = plt.figure(figsize=(16, 4.8))
    ax = fig.add_subplot(131, projection="3d"); ax.plot_surface(G1, G2, Z, cmap="viridis", linewidth=0, vmin=0, vmax=zmax)
    ax.set_title("Hàm thật $f$"); ax.set_xlabel("$x_1$"); ax.set_ylabel("$x_2$"); ax.set_zlim(0, zmax)
    ax = fig.add_subplot(132, projection="3d"); ax.plot_surface(G1, G2, Zp, cmap="viridis", linewidth=0, vmin=0, vmax=zmax)
    ax.scatter(X_test[:, 0], X_test[:, 1], y_test, s=12, c="red", label="Test (y thật)")
    ax.set_title("Bề mặt xấp xỉ $\\hat f$ của MLP"); ax.set_xlabel("$x_1$"); ax.set_ylabel("$x_2$"); ax.set_zlim(0, zmax); ax.legend(fontsize=8)
    ax = fig.add_subplot(133); cs = ax.contourf(G1, G2, err, levels=20, cmap="magma")
    ax.scatter(X_train_used[:, 0], X_train_used[:, 1], s=2, c="white", alpha=0.4)
    ax.set_title("Sai số tuyệt đối $|\\hat f - f|$ (chấm trắng: mẫu train)"); ax.set_xlabel("$x_1$"); ax.set_ylabel("$x_2$"); fig.colorbar(cs, ax=ax)
    _save("fig_final_surface.png")
    return float(err.max()), float(err.mean())
